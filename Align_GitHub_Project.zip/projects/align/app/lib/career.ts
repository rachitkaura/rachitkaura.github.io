import type {Item,Profile} from '../data';
const aliases:Record<string,string>={
 'program mgmt':'program management','project mgmt':'project management','ai ml':'artificial intelligence machine learning','ai and ml':'artificial intelligence machine learning','ai and machine learning':'artificial intelligence machine learning','artificial intelligence and machine learning':'artificial intelligence machine learning','machine learning and ai':'artificial intelligence machine learning',
 'js':'javascript','ts':'typescript','reactjs':'react','react js':'react','nodejs':'node js','aws':'amazon web services','gcp':'google cloud platform','ms azure':'azure','microsoft azure':'azure','api':'apis','api development':'apis','data analysis':'analytics','data analytics':'analytics','stakeholder mgmt':'stakeholder management','risk mgmt':'risk management','ci cd':'continuous integration continuous delivery'
};
export function normalizeSkill(value:string){const cleaned=value.normalize('NFKC').toLowerCase().replace(/&/g,' and ').replace(/[./_–—-]+/g,' ').replace(/\s+/g,' ').trim();return aliases[cleaned]||cleaned;}
export function splitSkills(value:string){return value.split(/[,;\n]/).map(x=>x.trim()).filter(Boolean);}
function uniqueSkills(values:string[]){const seen=new Set<string>();return values.filter(s=>{const k=normalizeSkill(s);if(!k||seen.has(k))return false;seen.add(k);return true})}
export function skillFit(profile:Pick<Profile,'skills'>,role:Item){const requirements=uniqueSkills(role.requiredSkills??role.tags);const skills=uniqueSkills(splitSkills(profile.skills));const matched=requirements.flatMap(required=>{const skill=skills.find(s=>normalizeSkill(s)===normalizeSkill(required));return skill?[{required,skill}]:[]});const missing=requirements.filter(r=>!matched.some(m=>normalizeSkill(m.required)===normalizeSkill(r)));return {score:requirements.length?Math.round(matched.length/requirements.length*100):null,requirements,matched,missing,skills};}
export type ApplicationDraft={id:string;profileId:string;role:Item;resume:string;coverLetter:string;createdAt:string;updatedAt:string;source:Profile;};
export function createDraft(profile:Profile,role:Item){const fit=skillFit(profile,role);const matchedKeys=new Set(fit.matched.map(m=>normalizeSkill(m.skill)));const skills=[...fit.skills.filter(s=>matchedKeys.has(normalizeSkill(s))),...fit.skills.filter(s=>!matchedKeys.has(normalizeSkill(s)))];const contact=[profile.location,profile.email,profile.links,profile.materials?.githubUrl].filter(Boolean).join(' | ');const experience=(profile.experience||'').trim();const sections=[profile.name,contact,`TARGET ROLE\n${role.title} | ${role.name}`,`PROFILE\n${profile.bio.trim()||'[Add your professional summary before submitting.]'}`,skills.length?`SKILLS\n${skills.join(' • ')}`:'',`EXPERIENCE\n${experience||'[Add verified job titles, employers, dates, and achievements before submitting.]'}`,profile.education?.trim()?`EDUCATION\n${profile.education.trim()}`:''];
 const allLines=experience.split(/\n+/).map(s=>s.trim()).filter(Boolean);
 const bulletLines=allLines.filter(line=>/^[•*-]\s+/.test(line));
 const narrativeLines=allLines.filter(line=>!line.includes('|')&&!/^\d{4}(?:\s*[–-]\s*(?:\d{4}|present))?$/i.test(line));
 const lines=bulletLines.length?bulletLines:narrativeLines;
 const ranked=lines.map((line,index)=>({line,index,score:fit.matched.reduce((n,m)=>n+(normalizeSkill(line).includes(normalizeSkill(m.skill))?1:0),0)})).sort((a,b)=>b.score-a.score||a.index-b.index).slice(0,2).sort((a,b)=>a.index-b.index);
 const evidence=ranked.length?`Relevant details from my background include:\n${ranked.map(x=>'• '+x.line.replace(/^[•*-]\s*/, '')).join('\n')}`:'[Add one or two verified achievements that are relevant to this role.]';
 const coverage=fit.matched.length?`The skills in my profile that align with your listed requirements include ${fit.matched.map(m=>m.skill).join(', ')}.`:'I would welcome a conversation to explore how my background relates to your team’s needs.';
 const letter=[profile.name,contact,`Hiring team\n${role.name}`,`Re: ${role.title}`,`Dear ${role.name} hiring team,`,`I am applying for the ${role.title} role at ${role.name}. ${profile.bio.trim()||'[Add a short introduction based on your experience.]'}`,coverage,evidence,'I would welcome the opportunity to discuss my experience and learn more about the team. Thank you for considering my application.',`Sincerely,\n${profile.name}`].filter(Boolean).join('\n\n');
 return {resume:sections.filter(Boolean).join('\n\n'),coverLetter:letter};}
export const hasPlaceholders=(text:string)=>/\[(?:Add|Verify|Insert)\b[^\]]*\]/i.test(text);
export function safeFilename(value:string){return value.normalize('NFKD').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-|-$/g,'').slice(0,100)||'application';}

export type ApplicationSourceIssue={field:'name'|'skills'|'experience';message:string};
export function applicationSourceIssue(source:Pick<Profile,'name'|'skills'|'experience'>):ApplicationSourceIssue|null {
 if(!source.name.trim())return {field:'name',message:'Enter your name before generating drafts.'};
 if(source.name.length>70)return {field:'name',message:'Keep your name to 70 characters or fewer.'};
 if(!splitSkills(source.skills).length)return {field:'skills',message:'Add at least one skill before generating drafts.'};
 if(source.skills.length>1000)return {field:'skills',message:'Keep the skills field to 1,000 characters or fewer.'};
 if(!source.experience?.trim())return {field:'experience',message:'Add your work experience before generating drafts.'};
 if(source.experience.length>20000)return {field:'experience',message:'Keep your source experience to 20,000 characters or fewer.'};
 return null;
}
